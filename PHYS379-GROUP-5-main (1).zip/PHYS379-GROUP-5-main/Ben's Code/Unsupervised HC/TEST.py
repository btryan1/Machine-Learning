from sklearn.preprocessing import normalize
from scipy.cluster.hierarchy import dendrogram, linkage
from matplotlib import pyplot as plt
import pandas as pd
import numpy as np
df = pd.read_csv(r'C:\Users\benti\Group Project 2\HC\Data\Galaxy Test2.csv')
print(df)
# generate two clusters: a with 100 points, b with 50:
np.random.seed(4711)  # for repeatability of this tutorial
a = np.random.multivariate_normal([10, 0], [[3, 1], [1, 4]], size=[100,])
b = np.random.multivariate_normal([0, 20], [[3, 1], [1, 4]], size=[50,])
c = np.random.multivariate_normal([60, 20], [[3, 1], [1, 4]], size=[50,])
d = np.random.multivariate_normal([20, 60], [[3, 1], [1, 4]], size=[50,])
e = np.random.multivariate_normal([60, 60], [[3, 1], [1, 4]], size=[50,])
f = np.random.multivariate_normal([30, 30], [[3, 1], [1, 4]], size=[50,])
X = np.concatenate((a, b,c,d,e,f),) # 150 samples with 2 dimensions

Z = linkage(X, 'complete')
fig = plt.figure(figsize=(25, 10))
plt.title('Truth Complete Dendrogram')
dn=dendrogram(Z)
plt.show()                    

