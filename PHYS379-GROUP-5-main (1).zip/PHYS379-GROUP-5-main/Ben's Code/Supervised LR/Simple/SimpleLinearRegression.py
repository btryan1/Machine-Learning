# "importing module NumPy to use the squareroot function"
import numpy as np

# "importing pandas to usitlize data manipulation functions"
import pandas as pd

# "Our class method containing all the statistical methods for Simple Linear Regression using the Least Squares Method"
class LeastSquares:

    # "A Class Method which calculates the mean of the inputted list arguement(data) and returns it as a floating point constant"
    def Mean(self,data):
        return sum(data)/float(len(data))


    # "A Class Method which calculates the 'pseudo' variance of the inputted list arguement(data) using the mean of that list and returns the value of this variance it as a 'pseudo' floating point constant"
    def Variance(self,data,mean):
        return sum((n-mean)**2 for n in data)

    # "calculates the 'pseudo' covariance of the inputted list arguements (x and y) using the values for the mean of those lists (x_mean and y_mean) and returns the value of this variance it as a 'pseudo' floating point constant"
    def Covariance(self,x,y,x_mean,y_mean):
        cov_xy=float(0)

        for n in range(len(y)):
            cov_xy += (x[n]-x_mean)*(y[n]-y_mean)
        return cov_xy

    # "A Class Method which calculates the straight line coefficients (alpha and beta) using the Least Square Method and returns them as floating point variables"
    def CoeffcientsCalculator(self,covar,var,x_mean,y_mean):
        alpha = float(covar/var)
        beta = float(y_mean - alpha*x_mean)

        return (alpha,beta)

    # "A Class Method which calculates the prediction values using our straight line coefficients , appends an initally empty list with the corresponding values and returns predictions as a list "
    def PredictionList(self,prediction_x,alpha,beta):
        prediction_list=list()

        for n in range(len(prediction_x)):
            y=alpha*prediction_x[n]+beta
            prediction_list.append(y)
        return prediction_list
    
    # "A Class Method which calculates the values for the partial derivatives of the cost function at the calculated straight line coefficients (since we already have a working algorithm (Least Squares Method), this was just prepartion for gradient descent and is not called)
    def Grad_CALC(self,alpha,beta,prediction_x,prediction_y,choice):
        E=float(0)
        if choice=='alpha':
            for n in range(len(prediction_y)):
                E += (prediction_x[n])*((alpha*prediction_x[n]+beta)-prediction_y[n])
            return (E)/len(prediction_y)
        else:
            for n in range(len(prediction_y)):
                E += (prediction_y[n]-(alpha*prediction_x[n]+beta))
            return -(E)/len(prediction_y)

    # "A Class Method which Calculates the Root Mean Square Error from our prediction list and the actual values"
    def RMSE_CALC(self,prediction_y,prediction_list):
        RMSE=float(0)

        for n in range(len(prediction_y)):
            RMSE += ((prediction_y[n]-prediction_list[n])**2)
        return np.sqrt(RMSE/len(prediction_y))

    
    # "A Class Method which Calculates the Mean Square Error from our prediction list and the actual values"
    def MSE_CALC(self,prediction_y,prediction_list):
        MSE=float(0)

        for n in range(len(prediction_y)):
            MSE += ((prediction_y[n]-prediction_list[n])**2)
            print(MSE)
        return MSE/(2*len(prediction_y))

    # "A Class Method which Calculates the Mean Absolute Error from our prediction list and the actual values"
    def MAE_CALC(self,prediction_y,prediction_list):
        MAE=float(0)

        for n in range(len(prediction_y)):
            MAE += np.abs(prediction_y[n]-prediction_list[n])
        return MAE/len(prediction_y)

    # "A Class Method which exports the inputted data frame arguements into .csv files to specified path locations"
    def Export_DF_As_CSV(self,our_prediction_df,train_df,prediction_df):
        print('Exporting Dataframes as CSV files...')
        our_prediction_df.to_csv(r'C:\Users\benti\Group Project 2\Simple Linear Regression\Data\Our_Prediction_DF.csv')
        print('Our_Prediction_DF.csv has been saved')

        train_df.to_csv(r'C:\Users\benti\Group Project 2\Simple Linear Regression\Data\Train_DF.csv') 
        print('Train_DF.csv has been saved')

        prediction_df.to_csv(r'C:\Users\benti\Group Project 2\Simple Linear Regression\Data\Prediction_DF.csv') 
        print('Prediction_DF.csv has been saved')
    
    # "A Class Method which generates a data frame composed of the 2 inputted lists"
    def List_To_DF(self,prediction_list,prediction_x):
        dict = {'Y': prediction_list, 'X': prediction_x} 
        our_prediction_df = pd.DataFrame(dict) 
        return our_prediction_df







