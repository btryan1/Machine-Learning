#"This file contains our main call function which uses the LeastSquares class methood to make predicitons, and export the resulting data sets"
#"It also contains an uncalled function GradientDescent() which was a working progress until work was made on multivariable gradient descent"

# "importing modules NumPy to utlise its mathemtical methods"
import numpy as np

# "Importing our LSM Statistics Class Method from Statistics.py file"
from SimpleLinearRegression import LeastSquares

# "Import pandas module to manipulate our data sets"
import pandas as pd

statistics=LeastSquares()
# "our main function containing all necesarry calls and variables needed to use LSM algorithm to make our predictions"
def Main():
    # "Imports our main data frame from the desired path"
    main_df=pd.read_csv(r'C:\Users\benti\Group Project 2\Simple Linear Regression\Data\GreyKangaroos.csv')

    # "splits our data frame into the desired train and prediction data frames with the specified 60/40 ratio"
    train_df=main_df.sample(frac=0.6,random_state=419)
    prediction_df=main_df.drop(train_df.index)

    # "extracts these two data frames into respective lists"
    train_x,train_y,prediction_x,prediction_y=train_df['X'].values.tolist(),train_df['Y'].values.tolist(),prediction_df['X'].values.tolist(),prediction_df['Y'].values.tolist()
    
    # "calculates our straight line coefficients using our CoeffcientCalculator class method , taking in the training lists and LSM stat values as arguements (arguements are also class methods just in order to be able to contain it on one line instead of multiple"
    alpha ,beta= statistics.CoeffcientsCalculator(statistics.Covariance(train_x,train_y,statistics.Mean(train_x),statistics.Mean(train_y)),statistics.Variance(train_x,statistics.Mean(train_x)),statistics.Mean(train_x),statistics.Mean(train_y))

    # "calculates our prediciton values as a list using our calculated straight line coefficinets"
    prediction_list=statistics.PredictionList(prediction_x,alpha,beta)
    print('Predictions list has been generated using Least Square Method from Stastics Class Method')

    # "converts the previously calculate prediction list into a data frame using the List_To_Df function"
    our_prediction_df = statistics.List_To_DF(prediction_list,prediction_x)

    # "Exports the dataframes as a .csv file in order to be able to plot our results"
    statistics.Export_DF_As_CSV(our_prediction_df,train_df,prediction_df)



#"Attempt at gradient descent using the lists we generated as well as the straight line coefficents however since LSM was extremely accurate for the 2D case we chose not to call this function but left it as a base for the multivariable case"
def GradientDescent(alpha,beta,prediction_x,prediction_y):
    grad_cost_alpha_0=statistics.Grad_CALC(alpha,beta,prediction_x,prediction_y,'alpha')
    grad_cost_beta_0=statistics.Grad_CALC(alpha,beta,prediction_x,prediction_y,'beta')
    learning_rate=0.0001

    if np.abs(grad_cost_alpha_0) and np.abs(grad_cost_beta_0) <0.0001:
        return alpha,beta
    else:
        for n in range(10):
            grad_cost_alpha=statistics.Grad_CALC(alpha,beta,prediction_x,prediction_y,'alpha')
            grad_cost_beta=statistics.Grad_CALC(alpha,beta,prediction_x,prediction_y,'beta')
            prediction_list=statistics.PredictionList(prediction_x,alpha,beta)
            cost=statistics.MSE_CALC(prediction_y,prediction_list)
            if np.abs(grad_cost_alpha) and np.abs(grad_cost_beta) <0.0001:
                print(cost)
                print(n)
                return alpha,beta
            else:
                print (cost)
                step_alpha=grad_cost_alpha*learning_rate
                step_beta=grad_cost_beta*learning_rate

                alpha_new=alpha-np.abs(step_alpha)
                beta_new=beta-np.abs(step_beta)
                alpha=alpha_new
                beta=beta_new
        return('no coeffs found')

#"Calls our main function, calculates the straight line coefficients using LSM and then exports the resulting data frames to be plotted in the Plot.py file"
Main()