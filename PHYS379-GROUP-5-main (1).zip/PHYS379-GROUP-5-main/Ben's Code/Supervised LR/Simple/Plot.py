#"This file contains all the functions and variables needed in order to plot our prediction data set aswell as other data sets alongside truth fits to compare our predcited values"

#"Imports modules needed to plot our data sets"
from matplotlib import pyplot as plt
import pandas as pd
import numpy as np
from SimpleLinearRegression import LeastSquares

#"Imports the data frames containing the required data sets for plotting"
main_df=pd.read_csv(r'C:\Users\benti\Group Project 2\Simple Linear Regression\Data\GreyKangaroos.csv')
our_prediction_df=pd.read_csv(r'C:\Users\benti\Group Project 2\Simple Linear Regression\Data\Our_Prediction_DF.csv')
train_df=pd.read_csv(r'C:\Users\benti\Group Project 2\Simple Linear Regression\Data\Train_DF.csv')
prediction_df=pd.read_csv(r'C:\Users\benti\Group Project 2\Simple Linear Regression\Data\Prediction_DF.csv')

#"defines our Least Square class method as statistics"
statistics=LeastSquares()

#"extracts the required data frames from the composite imported data frames"
main_x,main_y,train_x,train_y,prediction_x,prediction_y,our_prediction_x,our_prediction_y=main_df['X'],main_df['Y'],train_df['X'],train_df['Y'],prediction_df['X'],prediction_df['Y'],our_prediction_df['X'],our_prediction_df['Y']

#"calculates the straight line coefficients, firstly using our LeastSquares class method and then calculates the correct coefficients using NumPy polyfit method"
alpha ,beta= statistics.CoeffcientsCalculator(statistics.Covariance(train_x,train_y,statistics.Mean(train_x),statistics.Mean(train_y)),statistics.Variance(train_x,statistics.Mean(train_x)),statistics.Mean(train_x),statistics.Mean(train_y))
alpha_truth, beta_truth = np.polyfit(main_x, main_y, 1)


#"Plots our main data set and exports it as .pdf file to desired path"
def PlotMainData():
    plt.scatter(main_x,main_y)
    plt.xlabel('Nasal Length(x)[mm*10]')
    plt.ylabel('Nasal Width(y)[mm*10]')
    plt.title('Grey Kangaroos Noses Main Data')
    plt.savefig(r'C:\Users\benti\Group Project 2\Simple Linear Regression\Plots\GreyKangaroosMainData.pdf')

    print('GreyKangaroosMainData.pdf has been created')

    plt.clf()

#"Plots our test data set and exports it as .pdf file to desired path"
def PlotTestData():
    plt.scatter(train_x,train_y)
    plt.xlabel('Nasal Length(x)[mm*10]')
    plt.ylabel('Nasal Width(y)[mm*10]')
    plt.title('Grey Kangaroos Noses Test Data')

    plt.savefig(r'C:\Users\benti\Group Project 2\Simple Linear Regression\Plots\GreyKangaroosTestData.pdf')
    print('GreyKangaroosTestData.pdf has been created')
    
    plt.clf()

#"Plots our prediction data set (data set used when making the predictions) and exports it as .pdf file to desired path"
def PlotPredictionData():
    plt.scatter(prediction_x,prediction_y)
    plt.xlabel('Nasal Length(x)[mm*10]')
    plt.ylabel('Nasal Width(y)[mm*10]')
    plt.title('Grey Kangaroos Noses Prediction Data')

    plt.savefig(r'C:\Users\benti\Group Project 2\Simple Linear Regression\Plots\GreyKangaroosPredictionData.pdf')
    print('GreyKangaroosPredictionData.pdf has been created')
    
    plt.clf()
#"Plots the data set containing our predictions using LSM with a straight line fit and exports it as .pdf file to desired path "
def PlotOurPredictionData():
    plt.scatter(our_prediction_x,our_prediction_y)
    plt.plot(prediction_x, ((alpha*prediction_x) + beta))
    plt.scatter(main_x,main_y)
    plt.xlabel('Nasal Length(x)[mm*10]')
    plt.ylabel('Nasal Width(y)[mm*10]')
    plt.title('Grey Kangaroos Noses Our Prediction Data')

    plt.savefig(r'C:\Users\benti\Group Project 2\Simple Linear Regression\Plots\GreyKangaroosOurPredictionData.pdf')
    print('GreyKangaroosOurPredictionData.pdf has been created')
    
    plt.clf()

#"Plots the truth line vs the line for our prediciton valus and exports it as .pdf file to desired path "
def PlotTruthLineVsOurLine():
    plt.plot(prediction_x, ((alpha_truth*prediction_x) + beta_truth))
    plt.plot(prediction_x, ((alpha*prediction_x) + beta))
    plt.xlabel('Nasal Length(x)[mm*10]')
    plt.ylabel('Nasal Width(y)[mm*10]')
    plt.title('Grey Kangaroos Noses Our Prediction Vs Truth Line')

    plt.savefig(r'C:\Users\benti\Group Project 2\Simple Linear Regression\Plots\GreyKangaroosTruthLineVsOurLine.pdf')
    print('GreyKangaroosTruthLineVsOurLine.pdf has been created')
    plt.clf()

