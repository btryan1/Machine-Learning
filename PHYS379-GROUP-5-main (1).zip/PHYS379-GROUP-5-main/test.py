import numpy as np
import pandas as pd

dfT=pd.read_csv("datasets/modified_titanic.csv") #titanic dataset
dfT.dropna(subset=["Age", "Embarked"], inplace=True)
dfT.reset_index(drop=True, inplace=True)

dfT["Embarked"]=[0 if dfT["Embarked"][i]=="S" else 0.5 if dfT["Embarked"][i]=="C" else 1 for i in range(dfT.shape[0])]
dfT["Sex"]=[0 if dfT["Sex"][i]=="male" else 1 for i in range(dfT.shape[0])]
dfT["Pclass"]=[0 if dfT["Pclass"][i]==1 else 0.5 if dfT["Pclass"][i]==2 else 1 for i in range(dfT.shape[0])]

to_normalise = ["Age", "SibSp", "Parch", "Fare"]

for x in range(len(to_normalise)):
    max_i = max(dfT[to_normalise[x]])
    min_i = min(dfT[to_normalise[x]])
    dfT[to_normalise[x]]=[(dfT[to_normalise[x]][i]-min_i)/(max_i-min_i) for i in range(dfT.shape[0])]




print(dfT)