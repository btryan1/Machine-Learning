import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Import the data from *.csv file
data = pd.read_csv()

# Splits the data randomly into test and train with a fraction given by 'frac'
train = data.sample(frac=0.8, random_state=25)
test = data.drop(train.index)

# Reshape the training data and split into independent and dependent values
train_data = train.values
Y = train_data[:, -1].reshape(train_data.shape[0], 1)
X = train_data[:, :-1]

# Reshape the testing data and split into independent and dependent values
test_data = test.values
Y_test = test_data[:, -1].reshape(test_data.shape[0], 1)
X_test = test_data[:, :-1]

# Add ones to the first position in the matrix
X = np.vstack((np.ones((X.shape[0], )), X.T)).T
X_test = np.vstack((np.ones((X_test.shape[0], )), X_test.T)).T

def model(X, Y, learning_rate, iteration):
    """
    Input Parameters
    ----------------
    X : The independent variables of the training data.
    Y : The dependent varibale of the training data.
    learning_rate : The rate in which theta is updated.
    iteration : The number of iterations the method is run through.


    Output Parameters
    -----------------
    theta : The value of the intercept.
    cost_list : The cost at each interval is added to a list in order to see the change.

    """
    m = Y.size
    theta = np.zeros((X.shape[1], 1))
    cost_list = []

    for i in range(iteration):
        y_pred = np.dot(X, theta)
        
        cost = (1/(2*m))*np.sum(np.square(y_pred - Y))

        d_theta = (1/m)*np.dot(X.T, y_pred -Y)

        theta = theta - (learning_rate * d_theta)

        cost_list.append(cost)

        if(i%(iteration/10) == 0):
            print("Cost is :", cost)

    return theta, cost_list




# Number of iterations and learning rate
iteration = 10000
learning_rate = 0.0000005

# Create the model
theta, cost_list = model(X, Y, learning_rate = learning_rate, iteration = iteration)

# Plot of the cost function
rng = np.arange(0, iteration)
plt.plot(rng, cost_list)
plt.show()

# Find the error in predicted values
y_pred = np.dot(X_test, theta)
error = (1/X_test.shape[0])*np.sum(np.abs(y_pred - Y_test))

# Print the error and accuracy in percentages
print("Test error is :", error*100, "%")
print("Test Accuracy is :", (1-error)*100, "%")
