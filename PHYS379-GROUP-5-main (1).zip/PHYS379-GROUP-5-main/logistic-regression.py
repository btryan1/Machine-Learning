import numpy as np
import pandas as pd
import os

#data generated randomly
np.seterr(divide="ignore")
rng=np.random.default_rng(1)
mark1, mark2=rng.integers(101, size=100), rng.integers(101, size=100)
success=[0 if mark1[i]+mark2[i]<80 else 1 for i in range(100)] #pass test if combined result is over 80
df=pd.DataFrame(data={"Test 1 Results": mark1, "Test 2 Results": mark2, "Pass": success})

dfDJ=pd.read_csv("datasets/dow_jones_index.csv") #dow jones dataset
dfDJ.dropna(inplace=True)
dfDJ.reset_index(drop=True, inplace=True)

dfT=pd.read_csv("datasets/modified_titanic.csv") #titanic dataset
dfT.dropna(subset=["Age", "Embarked"], inplace=True)
dfT.reset_index(drop=True, inplace=True)

dfD=pd.read_excel("datasets/default_of_credit_card_clients.xls") #default credit card clients dataset - note that cost function does not work for this dataset due to there being so many features causing an overflow in the exp in the hypothesis function
dfD=dfD[:2000] #only using 2000 datapoints out of 30000 otherwise data amount is too large (overflow errors in numpy)

class LogisticRegression:

    def __init__(self, df, dataset):
        self.name, self.df, self.dataset="Logistic Regression", df, dataset
        self.split, self.lr, self.iterations=np.rint(0.8*self.df.shape[0]).astype(int), 0.125, 10000

    def datasets(self):
        if self.dataset==0:
            dfT, dfP=self.df.iloc[:self.split, :], self.df.iloc[self.split:, :] #80/20 training/predicting data split
            self.xP, self.yP=dfP[["Test 1 Results", "Test 2 Results"]], dfP["Pass"] #prediction data for generated data
            self.x, self.y=dfT[["Test 1 Results", "Test 2 Results"]], dfT["Pass"] #training data for generated data
        if self.dataset==1: #lr=0.02
            sizeDJ, columnsToRemove=self.df.shape[0], ["open", "high", "low", "close"]
            self.df["Up or Down"]=[1 if self.df["percent_change_next_weeks_price"][i]>0 else 0 for i in range(sizeDJ)]
            self.df.drop(columns=["stock", "date", "next_weeks_open", "next_weeks_close", "percent_change_next_weeks_price", "percent_return_next_dividend"], inplace=True)
            dollarRemove=[[float(self.df.loc[i, columns][1:]) for i in range(sizeDJ)] for columns in columnsToRemove]
            for i, columns in enumerate(columnsToRemove):
                self.df[columns]=dollarRemove[i]
            to_normalise = ["quarter", "open", "high", "low", "close", "volume", "percent_change_price", "percent_change_volume_over_last_wk", "previous_weeks_volume", "days_to_next_dividend"]
            for x in range(len(to_normalise)):
                max_i = max(self.df[to_normalise[x]])
                min_i = min(self.df[to_normalise[x]])
                self.df[to_normalise[x]]=[(self.df[to_normalise[x]][i]-min_i)/(max_i-min_i) for i in range(self.df.shape[0])]
            dfT, dfP=self.df.iloc[:self.split, :], self.df.iloc[self.split:, :] #80/20 training/predicting data split
            self.xP, self.yP=dfP[["quarter", "open", "high", "low", "close", "volume", "percent_change_price", "percent_change_volume_over_last_wk", "previous_weeks_volume", "days_to_next_dividend"]], dfP["Up or Down"] #prediction data for dow jones dataset
            self.x, self.y=dfT[["quarter", "open", "high", "low", "close", "volume", "percent_change_price", "percent_change_volume_over_last_wk", "previous_weeks_volume", "days_to_next_dividend"]], dfT["Up or Down"] #training data for dow jones dataset
        if self.dataset==2: #lr=0.15
            self.df["Embarked"]=[0 if self.df["Embarked"][i]=="S" else 0.5 if self.df["Embarked"][i]=="C" else 1 for i in range(self.df.shape[0])]
            self.df["Sex"]=[0 if self.df["Sex"][i]=="male" else 1 for i in range(self.df.shape[0])]
            self.df["Pclass"]=[0 if self.df["Pclass"][i]==1 else 0.5 if self.df["Pclass"][i]==2 else 1 for i in range(self.df.shape[0])]
            to_normalise = ["Age", "SibSp", "Parch", "Fare"]
            for x in range(len(to_normalise)):
                max_i = max(self.df[to_normalise[x]])
                min_i = min(self.df[to_normalise[x]])
                self.df[to_normalise[x]]=[(self.df[to_normalise[x]][i]-min_i)/(max_i-min_i) for i in range(self.df.shape[0])]
            dfT, dfP=self.df.iloc[:self.split, :], self.df.iloc[self.split:, :] #80/20 training/predicting data split
            self.xP, self.yP=dfP[["Pclass","Sex","Age","SibSp","Parch","Fare","Embarked"]], dfP["Survived"] #prediction data
            self.x, self.y=dfT[["Pclass","Sex","Age","SibSp","Parch","Fare","Embarked"]], dfT["Survived"] #training data
        if self.dataset==3:#lr=0.15
            self.df.drop(columns=["ID"], inplace=True)
            to_normalise = self.df.iloc[:, :23].columns
            for x in range(len(to_normalise)):
                max_i = max(self.df[to_normalise[x]])
                min_i = min(self.df[to_normalise[x]])
                self.df[to_normalise[x]]=[(self.df[to_normalise[x]][i]-min_i)/(max_i-min_i) for i in range(self.df.shape[0])]
            dfT, dfP=self.df.iloc[:self.split, :], self.df.iloc[self.split:, :] #80/20 training/predicting data split
            self.xP, self.yP=dfP.iloc[:, :23], dfP["default payment next month"] #prediction data
            self.x, self.y=dfT.iloc[:, :23], dfT["default payment next month"] #training data
        self.w, self.b=np.zeros(self.x.shape[1]), 0 #y=wx+b

    def hypothesis_function(self, z):
        return 1/(1+np.exp(-z))

    def cost_function(self):
        self.h=self.hypothesis_function(np.dot(self.x, self.w)+self.b)
        return -1/self.m * np.sum(self.y*np.log(self.h) + (1-self.y)*np.log(1-self.h))

    #constructs a line of best fit with logistic regression - improve fit with non-linear fit and minimising loss function
    def train(self):
        self.m=self.x.shape[0]
        for i in range(self.iterations):
            self.h=self.hypothesis_function(np.dot(self.x, self.w)+self.b)
            dw=1/self.m*np.dot(self.x.T,self.h-self.y)
            db=1/self.m*np.sum(self.h-self.y)
            self.w -= self.lr*dw
            self.b -= self.lr*db

    def run(self):
        #runs the fitting algorithm then prints out the weighting, bias how many are correct (out of 20) and the loss function
        self.datasets()
        self.train()
        print(self.xP) #left off here
        predictions=self.hypothesis_function(np.dot(self.xP, self.w)+self.b)>=0.5
        percentCorrect="{0}%".format(np.around(sum([1 if predictions[i]==self.yP[i+self.split] else 0 for i in range(self.yP.shape[0])])/self.yP.shape[0]*100, decimals=3))
        print(self.w, self.b, percentCorrect, self.cost_function())
        os.makedirs("datasets", exist_ok=True)
        self.df.to_csv("datasets/LogR_Normed_Titanic_data.csv", index=False) #set the index=False as it is not needed, when we load the data for graphing it is re-indexed

#Creates an instance using the generated data and runs it, change to dfDJ, dataset=1 to run Dow Jones logistic regression, dfT dataset=2 to run titanic dataset, dfD dataset=3 to run default credit card dataset
lrTest=LogisticRegression(dfT, dataset=2)
lrTest.run()


#exp(-z) is either inf or 0, dont know why, try adjusting parameters to fix