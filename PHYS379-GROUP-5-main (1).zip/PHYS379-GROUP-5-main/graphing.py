import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

x_data_column = 2 #column containing data, first column with data is 0 for DJ and CC, and 2 for Titanic
y_data_column = -1 #-1 for DJ and CC, 1 for Titanic
file_name = "datasets/logR_Normed_CC_data.csv" #file name of data

#retrieving data from *.csv file 
all_data = pd.read_csv(file_name)
x_data = all_data.iloc[:,x_data_column]
y_data = all_data.iloc[:,y_data_column]
x_label = "Payment Amount Current Month" #takes the relevant column header for label of axis (both x and y)
y_label = "Default Chance Next Month"

#titanic data - w=[-1.3745338   6.46155451 -0.26604505 -1.46420529 -0.89042989  0.06558927  0.48747439]  
#  b=0.8218519486998836    acc=73.239%    cf=1.8219722329631025
#normalised titanic data - w=[-2.45102929  2.59810434 -2.92467409 -1.49681575 -0.8522972   0.22193765  0.18918123]
#  b=1.3281926304481002   acc=82.394%   cf=0.45392223578415675
# "Pclass","Sex","Age","SibSp","Parch","Fare","Embarked"

#dow jones data - w=[9.66454861e-02 5.56214539e+00 5.72488406e+00 5.48134279e+00 5.64434030e+00 4.20864860e+03 1.30252906e-01 
# 9.59252341e-02 2.32304998e+03 3.30917161e+00]   b=0.07773541666667144   acc=45.139%   cf=n/a
#normalised dow jones - w=[-0.22772302  0.06382582  0.12967416  0.07374644  0.12388836 -0.57843155  0.50108255  0.29943935 
# -0.58911567 -0.32443263]   b=-0.13812987603043922  acc=52.778%  cf=0.6813841436367851
# "quarter", "open", "high", "low", "close", "volume", "percent_change_price", "percent_change_volume_over_last_wk", "previous_weeks_volume", "days_to_next_dividend"

#default credit cards data - w=[ -6.75482   0.02676292   0.039632     0.01857118   0.67520426   0.10032494   0.06103452   0.07955849
# 0.06433287   0.05963612   0.03664674  -4.60967967  -1.23302434   1.98387366  -2.37102968   2.38510181  -4.43930119 -10.11031086 
# -11.64876667  -1.82698315  -8.06776856   3.40295077   0.08807773   0.16557306]   b=0.015921417837649103  acc=76.5%  cf=n/a
#normalsied credit card - [ 0.35578519  0.06947252  0.04098092 -0.45944989  0.41193565  4.47639784 -0.10246166  1.36652275  0.53812611
#   1.10005435 -1.16618374 -0.33176671 -0.02618947  0.31126203  0.01912269 -0.18977718 -0.88283776 -1.2895341 -1.14996696 -0.69204836 
# -1.35036156  0.16801007  0.08717425]   b=-2.2359651491832935  acc=78.5%  cf=0.4707067295123795
# see: https://www.kaggle.com/uciml/default-of-credit-card-clients-dataset

w=-1.2895341
b=-2.2359651491832935

#finds the expected value/"probability" line for our data so we can plot it next to our points
line_x = []
line_y =[]
for i in range(231):
    x = (i)/100
    line_y.append(1/(1+np.exp(-(np.dot(x,w)+b))))
    line_x.append(x)

print(all_data)
print(x_data)

#plots data with round circles, then displays it

fig, ax = plt.subplots()
#ax.plot(x_data, y_data, 'ro')
ax.plot(line_x, line_y, 'b-') #this line plot doesn't appear correct to me at a glance, I don't know if thats because our data is completely random tho
ax.set_xlabel(x_label+" [NT Dollar]")
ax.set_ylabel(y_label)
ax.set_title(y_label+" compared to "+x_label)
ax.set_xticks([0,0.229, 0.458, 0.687, 0.916, 1.145, 1.374, 1.603, 1.832, 2.061, 2.290])
ax.set_xticklabels(["0", "200k", "400k", "600k", "800k", "1M", "1.2M", "1.4M", "1.6M", "1.8M", "2M"], rotation=0, ha='center')


plt.show()
