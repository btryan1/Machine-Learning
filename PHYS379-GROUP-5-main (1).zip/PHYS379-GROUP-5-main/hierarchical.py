import numpy as np
import pandas as pd
import string

df = pd.read_csv("datasets/hierarchical_clustering_data.csv", index_col=0)

print(df)

class HC:
    def __init__(self):
        pass

    """
    #Converts our import data frame into an array, it then generates a list composing of column vectors in order to utilise matrix multiplication for caluclating the distances etc.
    #It then returns this list to be utilised to calculate the initial distance matrix
    def Array_To_List_Col_Vec(self,df):
        test_array=pd.DataFrame.to_numpy(df)
        W=(np.shape(test_array)[1])
        list_col_vec=list()
        for i in range(W):
            list_col_vec.append(test_array[:,[i]])
        return(list_col_vec)
        """
    
    #creates a distance matrix in a dataframe. Diagonal is given "None" as a value
    def Distance_Matrix(self,dataframe):
        objects = dataframe.index
        distances = []
        for i in range(len(objects)): #i represents the column in the data matrix
            column = []
            for j in range(len(objects)): #j represents the row in the data matrix
                if j==i:
                    d = "None" #sets diagonal elements as "None" to indicate there is no data applicable
                else:
                    object_1 = [dataframe.iloc[i, 0], dataframe.iloc[i, 1]]
                    object_2 = [dataframe.iloc[j, 0], dataframe.iloc[j, 1]]
                    d = self.Euclidean_Dist(object_1, object_2)
                column.append(d)
            distances.append(column)

        distM = pd.DataFrame(distances, index=objects, columns=objects)
        return(distM)

        """
        M=np.zeros((len(list),len(list)),dtype=float)
        for i in range(len(list)):
            for j in range(len(list)):
                if i!=j :
                    X_i=list[i]
                    X_j=list[j]
                    distance=float(np.sqrt((X_i-X_j).T.dot(X_i-X_j)))
                    M[i][j]=distance
                else:
                    M[i][j]=419**(1.69)
        return(M)
        """


    #finds the distance between two points based on the Euclidean Method: d(p, q)=sqrt(Sum[(q_i - p_i)^2])
    def Euclidean_Dist(self, p, q):
        total = 0
        for i in range(len(p)):
            total += (q[i]-p[i])**2
        return np.sqrt(total)

    #finds the row and column number index with that contains the smallest value, and returns the row and column value
    def Find_Smallest_Dist(self, distM):
        current_dist = "None"
        down, across = 0, 0
        for i in range(len(distM.index)):
            for j in range(len(distM.columns)):
                test_dist = distM.iloc[i,j]
                if current_dist == "None":
                    current_dist = test_dist
                    down, across = i, j
                elif test_dist != "None":
                    if current_dist > test_dist:
                        current_dist = test_dist
                        down, across = i, j
        return down, across
 
    #Method: 1 - Simple linkage, 2 - Complete linkage, 3 - Mean linkage
    def Cluster(self, method, distM, obj_1, obj_2):
        if method == 1:
            return self.Min_Distance_Calc(distM, obj_1, obj_2)
        elif method == 2:
            return self.Max_Distance_Calc(distM, obj_1, obj_2)
        elif method == 3:
            return self.Average_Distance_Calc_WPGMA(distM, obj_1, obj_2)


    #Simple-Linkage Criteria - Measure the distances from the CLOSEST points of each cluster, and merge the clusters with smallest distance
    #   looks at the two objects we are combining. Compares the distances to other objects in the distance matrix and chooses the smallest
    #    distance every time. Then we return a new distance matrix with this clustered object that contains the smallest distances to every other cluster/object
    def Min_Distance_Calc(self, distM, obj_1, obj_2):
        i = distM.index[obj_1]
        j = distM.columns[obj_2]
        new_name = "("+i+j+")"

        newDistM = distM.drop([i,j], axis=0)
        newDistM.drop([i,j], axis=1, inplace=True)

        new_row = []
        for count in range(len(distM.index)):
            dist_1 = distM.iloc[obj_1, count]
            dist_2 = distM.iloc[obj_2, count]
            if dist_1!="None" and dist_2!="None":
                new_dist = min(dist_1, dist_2)
                new_row.append(new_dist)

        newDistM[new_name] = new_row
        new_row.append("None")
        newDistM.loc[new_name]= new_row

        return newDistM
               
        """
        min=np.min(M)
        min_list=list()
        if choice == 1:
            for i in range(np.shape(M)[0]):
                for j in range(np.shape(M)[0]):
                    if min==M[i][j]:
                        return i,j,min
                    else:
                        continue
        else:
            for i in range(np.shape(M)[0]):
                for j in range(np.shape(M)[0]):
                    if i!=j and M[i][j]!= minimum and M[i+1][j]!=419**(1.69):
                            a=M[i][j]
                            b=M[i+1][j]
                            array=np.array((a,b),dtype=float)
                            print(np.min(array))
                    else:
                        continue
        return min_list
        """

    #Complete-Linkage Criteria - Measure the distances from the FURTHEST points of each cluster, and merge the clusters with smallest distance
    #   looks at the two objects we are combining. Compares the distances to other objects in the distance matrix and chooses the largest
    #    distance every time. Then we return a new distance matrix with this clustered object that contains the largest distances to every other cluster/object
    def Max_Distance_Calc(self, distM, obj_1, obj_2):
        i = distM.index[obj_1]
        j = distM.columns[obj_2]
        new_name = "("+i+j+")"

        newDistM = distM.drop([i,j], axis=0)
        newDistM.drop([i,j], axis=1, inplace=True)

        new_row = []
        for count in range(len(distM.index)):
            dist_1 = distM.iloc[obj_1, count]
            dist_2 = distM.iloc[obj_2, count]
            if dist_1!="None" and dist_2!="None":
                new_dist = max(dist_1, dist_2)
                new_row.append(new_dist)

        newDistM[new_name] = new_row
        new_row.append("None")
        newDistM.loc[new_name]= new_row

        return newDistM

    #Mean-Linkage Criteria - Measure the distances from the CENTRE of each cluster, and merge the clusters with smallest distance
    def Average_Distance_Calc_WPGMA(self, distM, obj_1, obj_2):
        i = distM.index[obj_1]
        j = distM.columns[obj_2]
        new_name = "("+i+j+")"

        newDistM = distM.drop([i,j], axis=0)
        newDistM.drop([i,j], axis=1, inplace=True)

        new_row = []
        for count in range(len(distM.index)):
            dist_1 = distM.iloc[obj_1, count]
            dist_2 = distM.iloc[obj_2, count]
            if dist_1!="None" and dist_2!="None":
                new_dist = (dist_1 + dist_2)/2
                new_row.append(new_dist)

        newDistM[new_name] = new_row
        new_row.append("None")
        newDistM.loc[new_name]= new_row

        return newDistM



#calculates the branch lengths of the branches connecting the clustered elements/clusters to their respective nodes , at the moment it is very basic
def Branch_Length_Calc(self,min):
    return min/2
    #note from Stephen: I haven't made use of this yet so we can't draw the correct height of the dendrogram yet, only the what is clustered to what
                    

        
HC=HC()
#list_=HC.Array_To_List_Col_Vec(df)
distM=HC.Distance_Matrix(df)
print(distM)
for iterations in range(len(df.index)-1):
    obj_1, obj_2= HC.Find_Smallest_Dist(distM)
    distM = HC.Cluster(3, distM, obj_1, obj_2) #Method: 1 - Simple linkage, 2 - Complete linkage, 3 - Mean linkage
print(distM.index[0])
