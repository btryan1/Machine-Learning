import pandas as pd

letters = ['A', 'B', 'C', 'D', 'E', 'F']
data = [(1,1), (1.5,1.5), (5,5), (3,4), (4,4), (3,3.5)]

"""
This is our test data set:
A,1,1
B,1.5,1.5
C,5,5
D,3,4
E,4,4
F,3,3.5
"""

df=pd.DataFrame(data, index=letters, columns=['x', 'y'])

print(df)

df.to_csv("datasets/hierarchical_clustering_data.csv")