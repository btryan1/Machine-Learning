import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.colors as mcolours

class KMean:

    def __init__(self, x):
        self.k=6 #number of clusters
        self.x=x #the datapoints
        self.iterations=1000
        self.rng=np.random.default_rng(1)
        self.fig, self.axs = plt.subplots(nrows=1, ncols=2, sharex=True, sharey=True)       

    def centroid(self):
        y={}
        distances=np.array([]).reshape(self.x.shape[0], 0)
        for i in range(self.k):
            temp=np.sum((self.x-self.centroids[:, i])**2, axis=1)
            distances=np.c_[distances, temp]
            y[i+1]=np.array([]).reshape(self.x.shape[1], 0)
        minimumCentroid=np.array([np.argmin(i)+1 for i in distances])
        for j in range(self.x.shape[0]):
            y[minimumCentroid[j]]=np.c_[y[minimumCentroid[j]], self.x[j]]
        for k in range(self.k):
            y[k+1]=y[k+1].T
            self.centroids[:, k]=np.mean(y[k+1], axis=0)
        self.result=y

    #runs the K-Mean clustering algorithm for a number of iterations
    def run(self):
        self.idx=self.rng.choice(self.x.shape[0], self.k, replace=False) #picking out the data points from the dataset idx means index small subsection of dataset used in machine learning
        #choose centroids from the dataset and find the distance between the centroids and all the data points, also need to get the centriod with minimum distance
        self.centroids=self.x[self.idx, :].reshape(self.x.shape[1], self.k)
        for x in range(self.iterations):
            self.centroid()

    def plotData(self):
        self.axs[0].scatter(self.x[:, 0], self.x[:, 1], c="black", label="Unclustered digits data")
        #self.axs[0].set_ylabel("IDK")
        self.axs[0].legend()

    #scatter plot using matplotlib
    def plotClusters(self):
        colours=[colour for colour in mcolours.TABLEAU_COLORS]
        labels=["Cluster {0}".format(num+1) for num in range(self.k)]
        for k in range(self.k):
            self.axs[1].scatter(self.result[k+1][:, 0], self.result[k+1][:, 1], c=colours[k], label=labels[k])
        self.axs[1].scatter(self.centroids[0, :], self.centroids[1, :], s=300, c="yellow", label="Centroids")
        #self.axs[1].set_xlabel("IDK 2")
        self.axs[1].legend()
        self.fig.suptitle("Handwritten Digits Dataset K-Means Clustering Before and After")
        self.fig.tight_layout()
        plt.show()

    #plot of WCSS vs number of clusters using matplotlib
    def plotWCSS(self):
        plt.plot(np.arange(1, 10, 1), self.WCSS)
        plt.xlabel("# of Clusters, k")
        plt.ylabel("WCSS")
        plt.show()

    #ELBOW method using WCSS (WCSS is the sum of squared distance between each point and the centroid in a cluster) to find optimal number of clusters k
    def ELBOW(self):
        self.WCSS=[]
        for x in range(1, 10):
            self.k=x
            self.run()
            WCSS=0
            for i in range(self.k):
                WCSS+=np.sum((self.result[i+1]-self.centroids[:, i])**2)
            self.WCSS.append(WCSS)

df=pd.read_csv("datasets/customers.csv")
x=df.loc[:, ["Annual Income (k$)", "Spending Score (1-100)"]].values
dfd=pd.read_csv("datasets/digits_processed.csv")
dfH=pd.read_csv("datasets/housing.csv")
xH=dfH.loc[:, ["longitude", "latitude"]].values
#Use x for customers dataset, dfd.values for digits dataset, xH for housing dataset
test=KMean(x)
test.plotData()
test.run()
test.plotClusters()
#to run the ELBOW method add comment to the two lines above and remove from the two lines below
"""test.ELBOW()
test.plotWCSS()"""
